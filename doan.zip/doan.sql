-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 05, 2022 lúc 04:39 AM
-- Phiên bản máy phục vụ: 10.4.21-MariaDB
-- Phiên bản PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', 'c4ca4238a0b923820dcc509a6f75849b');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_cart_detail`
--

CREATE TABLE `tbl_cart_detail` (
  `id_cart_detail` int(11) NOT NULL,
  `code_cart` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_sanpham` int(11) NOT NULL,
  `soluongmua` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_cart_detail`
--

INSERT INTO `tbl_cart_detail` (`id_cart_detail`, `code_cart`, `id_sanpham`, `soluongmua`) VALUES
(42, '5762', 17, 1),
(43, '4383', 17, 1),
(44, '1406', 28, 2),
(45, '1406', 26, 1),
(46, '6221', 28, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_dangky`
--

CREATE TABLE `tbl_dangky` (
  `id_khachhang` int(11) NOT NULL,
  `hovaten` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taikhoan` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `matkhau` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sodienthoai` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diachi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `chucvu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_dangky`
--

INSERT INTO `tbl_dangky` (`id_khachhang`, `hovaten`, `taikhoan`, `matkhau`, `sodienthoai`, `email`, `diachi`, `chucvu`) VALUES
(5, 'buihongsang', 'sang', '202cb962ac59075b964b07152d234b70', 987, 'buisang2909@gmail.com', 'abc', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_danhmuc`
--

CREATE TABLE `tbl_danhmuc` (
  `id_danhmuc` int(11) NOT NULL,
  `tendanhmuc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thutu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_danhmuc`
--

INSERT INTO `tbl_danhmuc` (`id_danhmuc`, `tendanhmuc`, `thutu`) VALUES
(9, 'Dầu gội', 1),
(10, 'Bánh', 2),
(11, 'Kẹo', 3),
(12, 'Sữa', 4),
(13, 'Đồ ăn nhanh', 5),
(15, 'Nước', 6),
(16, 'Gia vị', 7);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_giohang`
--

CREATE TABLE `tbl_giohang` (
  `id_cart` int(11) NOT NULL,
  `id_khachhang` int(11) NOT NULL,
  `code_cart` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cart_status` int(11) NOT NULL,
  `cart_payment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_giohang`
--

INSERT INTO `tbl_giohang` (`id_cart`, `id_khachhang`, `code_cart`, `cart_status`, `cart_payment`) VALUES
(39, 4, '5762', 0, 'Tiền Mặt'),
(40, 4, '4383', 0, 'Chuyển Khoảng'),
(41, 4, '1406', 1, 'Tiền Mặt'),
(42, 5, '6221', 1, 'Tiền Mặt');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_sanpham`
--

CREATE TABLE `tbl_sanpham` (
  `id_sanpham` int(11) NOT NULL,
  `tensanpham` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `masanpham` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `giasanpham` float NOT NULL,
  `soluong` int(11) NOT NULL,
  `hinhanh` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tomtat` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `noidung` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_danhmuc` int(11) NOT NULL,
  `trangthai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tbl_sanpham`
--

INSERT INTO `tbl_sanpham` (`id_sanpham`, `tensanpham`, `masanpham`, `giasanpham`, `soluong`, `hinhanh`, `tomtat`, `noidung`, `id_danhmuc`, `trangthai`) VALUES
(17, 'kẹo', '123', 5000, 50, 'keoalpenliebe.jpg', 'Viên kẹo dẻo mềm dai dai, với vị thơm lừng của ca cao, kích thích mọi giác quan', '', 11, 1),
(18, 'kẹo Dynamite', '121', 23900, 10, '8934564100369.jpg', 'Lớp vỏ bạc hà the mát, bọc lấy nhân socola thơm béo, tạo cảm giác thích thú khi thưởng thức. Gói lớn giá tiết kiệm, thích hợp cho các buổi liên hoan, tiệc sinh nhật cho bé,...', 'Lớp vỏ bạc hà the mát, bọc lấy nhân socola thơm béo, tạo cảm giác thích thú khi thưởng thức. Gói lớn giá tiết kiệm, thích hợp cho các buổi liên hoan, tiệc sinh nhật cho bé,...Kẹo hương bạc hà nhân socola Dynamite Big Bang gói 330g ngọt thanh mang đến cho bạn sự dễ chịu.', 11, 1),
(19, 'Kẹo dừa sọc ca cao Yến Hoàng', '120', 27000, 30, 'keo-dua-soc-ca-cao-yen-hoang-hop-250g-202006270832381212.jpg', 'Viên kẹo dẻo mềm dai dai, với vị thơm lừng của ca cao, kích thích mọi giác quan.', 'Viên kẹo dẻo mềm dai dai, với vị ngọt đậm thơm lừng của socola, kích thích mọi giác quan. Kẹo dừa sọc ca cao Yến Hoàng hộp 250g thơm mùi dừa và còn cả vị socola khá thơm, ăn không ngọt gắt cổ họng. Kẹo dừa Yến Hoàng vừa ăn vừa thưởng trà thư giãn là số 1 nhé', 11, 1),
(20, 'Kẹo dẻo vị cam chanh Play More ', '122', 19000, 30, 'sellingpoint.jpg', 'Sản phẩm dễ sử dụng, dùng cho bé ăn trực tiếp, vị cam chanh chua ngọt hài hoà, kích thích vị giác.', 'Từng viên kẹo dẻo mềm dai, thơm ngon, với khuôn mẫu những hình ảnh 3D độc đáo, vị cam chanh chua ngọt hài hoà, kích thích vị giác. Kẹo dẻo vị cam chanh Play More gói 48g thơm thơm, ăn có vị ngọt thanh, kẹo lại dai vô cùng thích. Kẹo Play More là thương hiệu của Thái Lan', 11, 1),
(21, 'Nước ngọt Coca Cola', '220', 10000, 50, '6-chai-nuoc-ngot-coca-cola-390ml-202205101334289840.jpg', 'Từ thương hiệu nước giải khát hàng đầu thế giới, nước ngọt Coca Cola chai 390ml xua tan nhanh mọi cảm giác mệt mỏi, căng thẳng, đặc biệt thích hợp sử dụng với các hoạt động ngoài trời. Bên cạn', '', 14, 1),
(22, 'Lon nước ngọt Coca Cola', '220', 10000, 50, '6-lon-nuoc-ngot-coca-cola-235ml-202201172244432954.jpg', 'Từ thương hiệu loại nước ngọt giải khát Coca Cola được nhiều người yêu thích với hương vị thơm ngon, sảng khoái. 6 lon nước ngọt Coca Cola lon 235ml với lượng gas lớn sẽ giúp bạn xua tan mọi cảm gi', '', 14, 1),
(23, 'Nước ngọt 7 Up vị chanh', '221', 10000, 50, '6-lon-nuoc-ngot-7-up-vi-chanh-320ml-202205101502433747.jpg', 'Từ thương hiệu nước ngọt 7Up uy tín được ưa chuộng. 6 lon nước ngọt 7 Up hương chanh lon 320ml có vị ngọt vừa phải và hương vị gas the mát, giúp bạn xua tan nhanh chóng cơn khát, giảm cảm giác ngấy, k?', '', 14, 1),
(24, 'Nước tăng lực Compact vị cherry', '222', 10000, 50, '6-chai-nuoc-tang-luc-compact-vi-cherry-330ml-202103272202321013.jpg', 'Sản phẩm nước tăng lực chất lượng từ thương hiệu Compact. 6 chai nước tăng lực Compact vị cherry 330ml sản xuất trên dây chuyền hiện đại từ Nhật Bản với vị cherry thơm ngon dễ uống cho cơ thể s??', '', 14, 1),
(25, 'Lon nước ngọt Pepsi không calo', '223', 10000, 50, 'loc-6-lon-nuoc-ngot-pepsi-khong-calo-330ml-202103162336336531.jpg', 'Là loại nước ngọt được nhiều người yêu thích đến từ thương hiệu nổi tiếng thế giới Pepsi với hương vị thơm ngon, sảng khoái. 6 lon nước ngọt Pepsi không calo lon 320ml với lượng gas lớn sẽ giúp', '', 14, 1),
(26, 'Thùng 30 gói mì Hảo Hảo ', '330', 112000, 30, 'thung-30-goi-mi-hao-hao-tom-chua-cay-75g-202110110920329170.jpg', 'Sợi mì vàng dai ngon hòa quyện trong nước súp tôm chua cay Hảo Hảo, đậm đà thấm đẫm từng sợi sóng sánh cùng hương thơm quyến rũ ngất ngây. Mì Hảo Hảo tôm chua cay gói 75g là lựa chọn hấp dẫn không', '', 13, 1),
(27, 'Thùng 30 gói mì xào Hảo Hảo ', '331', 110000, 30, 'thung-30-goi-mi-xao-hao-hao-tom-hanh-75g-202007041424418354.jpg', 'Sợi mì vàng dai ngon hòa trong nước sốt mì xào tôm hành Hảo Hảo thơm lừng, đậm đà thấm đẫm từng sợi mì sóng sánh cùng hương thơm quyến rũ ngất ngây. 30 gói mì xào Hảo Hảo tôm hành 75g,lựa chọn h', '', 13, 1),
(28, 'Xúc xích Vissan', '410', 12000, 50, '7a7d6f96baa338f1d58130e1d3f97c48.jpg', 'Thành phần Thịt heo, mỡ heo, protein đậu nành, chất xơ, DHA, đường, muối, tiêu\r\nCách dùng Ăn liền hoặc ăn kèm mì, bánh mì, pizza,...', '', 13, 1),
(29, 'Nước ngọt Coca Cola', '220', 60000, 50, '6-chai-nuoc-ngot-coca-cola-390ml-202205101334289840.jpg', 'Coca-Cola đôi khi được sử dụng để điều trị phytobezoar dạ dày. Trong khoảng 50% trường hợp được nghiên cứu, chỉ riêng Coca-Cola đã được tìm thấy có hiệu quả trong việc hòa tan phytobezoar dạ dày.', '', 15, 1),
(30, 'Lon nước ngọt Coca Cola', '221', 60000, 50, '6-lon-nuoc-ngot-coca-cola-235ml-202201172244432954.jpg', 'Coca-Cola đôi khi được sử dụng để điều trị phytobezoar dạ dày. Trong khoảng 50% trường hợp được nghiên cứu, chỉ riêng Coca-Cola đã được tìm thấy có hiệu quả trong việc hòa tan phytobezoar dạ dày.', '', 15, 1),
(31, 'Nước dừa đóng chai', '222', 10000, 50, '1870_i5f8aaa236823b.jpg', 'Nước dừa có cơm dừa Thương Hiệu JOY là một dòng sản phẩm mới thành phần 100% nước dừa tự nhiên nguyên chất, sản xuất trên công nghệ tiên tiến Nano Collagen, là loại thức uống giải khát bổ dưỡn', '', 15, 1),
(32, 'nước khoáng', '223', 5000, 80, '20200703_083647_477353_unnamed.max-1800x1800.png', 'Không giống như các loại nước khác, nước khoáng được đóng chai chính tại nguồn nước, có chứa các khoáng chất tự nhiên và nhiều nguyên tố vi lượng khác. ', '', 15, 1),
(33, 'sữa tươi vinamilk ', '400', 60000, 50, '207a14f1a36368590a76a3d5e4bb71ed.jpg', '', '', 12, 1),
(34, 'sữa socola th truemilk', '401', 30000, 50, 'loc-4-hop-sua-tuoi-tiet-trung-socola-th-true-milk-180ml-202104091509464500.jpg', 'Sữa tươi tiệt trùng TH true MILK sô cô la được làm từ nguồn sữa bò tươi sạch được chăn nuôi theo tiêu chuẩn nghiêm ngặt tại các trang trại của TH.\r\n\r\nSữa không chỉ có hương vị thơm ngon mà còn chứ', '', 12, 1),
(35, 'Sữa chua TH true milk ', '411', 20000, 50, 'd21c5e3129cd39329b8f228ee64bdae1.jpg', 'Hương vị thơm ngon, phù hợp nhiều khẩu vị\r\nCó nhiều công dụng tốt đối với sức khỏe\r\nĐóng hộp nhỏ gọn, tiện lợi thưởng thức, bảo quản', '', 12, 1),
(36, 'bánh đậu xanh', '500', 40000, 30, 'banh-dau-xanh-minh-ngoc-banh-dau-xanh-tra-xanh-vietmart-sieu-thi-thuc-pham-viet-tai-nhat.jpg', '', '', 10, 1),
(37, 'bột canh i-ot', '700', 4000, 50, '85863480f7753095762d957c6a9805f9.jpg', '', '', 16, 1),
(38, 'bột ngọt', '702', 20000, 50, 'bot-ngot-ajinomoto-goi-1kg-201912111050340356.jpg', '', '', 16, 1),
(39, 'bột nêm', '703', 40000, 50, '42f6c35a1ada960e351d8011eb44d7a6.jpg', '', '', 16, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `id_shipping` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `adress` varchar(250) NOT NULL,
  `note` varchar(250) NOT NULL,
  `id_dangky` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Chỉ mục cho bảng `tbl_cart_detail`
--
ALTER TABLE `tbl_cart_detail`
  ADD PRIMARY KEY (`id_cart_detail`);

--
-- Chỉ mục cho bảng `tbl_dangky`
--
ALTER TABLE `tbl_dangky`
  ADD PRIMARY KEY (`id_khachhang`);

--
-- Chỉ mục cho bảng `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  ADD PRIMARY KEY (`id_danhmuc`);

--
-- Chỉ mục cho bảng `tbl_giohang`
--
ALTER TABLE `tbl_giohang`
  ADD PRIMARY KEY (`id_cart`);

--
-- Chỉ mục cho bảng `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  ADD PRIMARY KEY (`id_sanpham`);

--
-- Chỉ mục cho bảng `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`id_shipping`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `tbl_cart_detail`
--
ALTER TABLE `tbl_cart_detail`
  MODIFY `id_cart_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT cho bảng `tbl_dangky`
--
ALTER TABLE `tbl_dangky`
  MODIFY `id_khachhang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  MODIFY `id_danhmuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `tbl_giohang`
--
ALTER TABLE `tbl_giohang`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT cho bảng `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  MODIFY `id_sanpham` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT cho bảng `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `id_shipping` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
